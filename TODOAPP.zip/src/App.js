 
import './App.css';
import Todo from './compounents/Todo'
function App() {
  return (
    <>
     <Todo/>
    
    </>
  );
}

export default App;
