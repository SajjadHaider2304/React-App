import React, { useState } from 'react'
import note from '../../src/note.png'

import { FaPlus } from "react-icons/fa";
import { FaTrashAlt } from "react-icons/fa";
export default function Todo() {

    const [inputdata, setInputdata] = useState('');
    const [items, setItems] = useState([]);


    const additem = () => {


        if (!inputdata) {

        }
        else {
            setItems([...items, inputdata]);
            setInputdata('');

        }
    }
    const deleteItem = (id) => {
        const updateData = items.filter((element , ind)=>{
            return ind == id
        });
        setItems(updateData)

    }
    const removeAll=()=>{
        setItems([])
    }

    return (



        <>
            <div className="main-div">
                <div className="child-div">

                    <figure>
                        <img src={note} alt="" />
                        {/* <h1 style={{ color: "white", margin: 10 }}> Welcome to Todo Application 🤘</h1> */}
                        <figcaption>Add Todo List Here 😍</figcaption>
                    </figure>
                    <div className="addItems">
                        <input type="text" placeholder='✍  Add Item... '
                            value={inputdata}
                            onChange={(e) => setInputdata(e.target.value)}
                        />
                        <span className='add-btn' title='Add Item' onClick={additem} > <FaPlus /></span>


                    </div>

                    <div className="showItems">

                        {
                            items.map((element, index) => {
                                return (

                                    <div className='eachItem' key={index}>
                                        <h3>{element}</h3>
                                        <span className='add-btnn ' title='Delete Item' onClick={() => deleteItem(index)}> <FaTrashAlt /></span>
                                    </div>

                                )
                            })


                        }



                    </div>
                    <div className="showItems">
                        <button onClick={removeAll} className='btn effect04' ><b>Remove All Todo</b></button>

                    </div>

                </div>
            </div>

        </>
    )
}
